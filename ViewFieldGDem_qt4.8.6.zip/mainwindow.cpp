#include "mainwindow.h"

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QTextEdit>
#include <QLabel>
#include <QFileDialog>
#include <QImage>
#include <QPixmap>
#include <QtMath>
#include <QMessageBox>
#include <QGridLayout>
#include <QPen>
#include <QBrush>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      m_view(0),
      m_scene(0),
      m_fileEdit(0),
      m_loadButton(0),
      m_centerX(0),
      m_centerY(0),
      m_radius(0),
      m_fovDeg(0),
      m_cameraHeight(0),
      m_output(0)
{
    QWidget *central = new QWidget(this);
    setCentralWidget(central);

    m_scene = new QGraphicsScene(this);
    m_view = new QGraphicsView(m_scene, this);
    m_view->setRenderHint(QPainter::Antialiasing, false);
    m_view->setRenderHint(QPainter::SmoothPixmapTransform, false);

    m_fileEdit = new QLineEdit(this);
    m_loadButton = new QPushButton("Load DEM", this);
    connect(m_loadButton, SIGNAL(clicked()), this, SLOT(onLoadDem()));

    m_centerX = new QSpinBox(this);
    m_centerY = new QSpinBox(this);
    m_radius  = new QSpinBox(this);

    m_centerX->setRange(0, 9999);
    m_centerY->setRange(0, 9999);
    m_radius->setRange(1, 5000);

    m_fovDeg = new QDoubleSpinBox(this);
    m_fovDeg->setRange(1.0, 180.0);
    m_fovDeg->setValue(60.0);

    m_cameraHeight = new QDoubleSpinBox(this);
    m_cameraHeight->setRange(0.0, 100000.0);
    m_cameraHeight->setValue(1000.0);

    QPushButton *computeBtn = new QPushButton("Compute ViewField", this);
    connect(computeBtn, SIGNAL(clicked()), this, SLOT(onComputeViewField()));

    m_output = new QTextEdit(this);
    m_output->setReadOnly(true);

    QVBoxLayout *rightLayout = new QVBoxLayout;
    QHBoxLayout *fileLayout = new QHBoxLayout;
    fileLayout->addWidget(new QLabel("DEM file:", this));
    fileLayout->addWidget(m_fileEdit);
    fileLayout->addWidget(m_loadButton);

    rightLayout->addLayout(fileLayout);

    QGridLayout *paramsLayout = new QGridLayout;
    int row = 0;
    paramsLayout->addWidget(new QLabel("Center X (col):", this), row, 0);
    paramsLayout->addWidget(m_centerX, row, 1);
    ++row;

    paramsLayout->addWidget(new QLabel("Center Y (row):", this), row, 0);
    paramsLayout->addWidget(m_centerY, row, 1);
    ++row;

    paramsLayout->addWidget(new QLabel("Radius (cells):", this), row, 0);
    paramsLayout->addWidget(m_radius, row, 1);
    ++row;

    paramsLayout->addWidget(new QLabel("FOV (deg):", this), row, 0);
    paramsLayout->addWidget(m_fovDeg, row, 1);
    ++row;

    paramsLayout->addWidget(new QLabel("Camera height:", this), row, 0);
    paramsLayout->addWidget(m_cameraHeight, row, 1);
    ++row;

    rightLayout->addLayout(paramsLayout);
    rightLayout->addWidget(computeBtn);
    rightLayout->addWidget(new QLabel("Heights inside view field:", this));
    rightLayout->addWidget(m_output, 1);

    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addWidget(m_view, 1);
    mainLayout->addLayout(rightLayout, 0);

    central->setLayout(mainLayout);

    resize(1000, 600);
    setWindowTitle("ViewField to Height at DEM - Qt 4.8.6");
}

MainWindow::~MainWindow()
{
}

void MainWindow::onLoadDem()
{
    QString fileName = QFileDialog::getOpenFileName(
                this,
                "Select DEM file",
                QString(),
                "Text files (*.txt);;All files (*.*)");
    if (fileName.isEmpty())
        return;

    m_fileEdit->setText(fileName);
    QString err;
    if (!m_dem.loadFromFile(fileName, &err)) {
        QMessageBox::critical(this, "Error", err);
        return;
    }

    m_centerX->setRange(0, m_dem.cols() - 1);
    m_centerY->setRange(0, m_dem.rows() - 1);
    m_radius->setRange(1, qMax(m_dem.rows(), m_dem.cols()));

    rebuildScene();
}

void MainWindow::rebuildScene()
{
    m_scene->clear();

    if (m_dem.rows() <= 0 || m_dem.cols() <= 0)
        return;

    int rows = m_dem.rows();
    int cols = m_dem.cols();

    QImage img(cols, rows, QImage::Format_Indexed8);
    img.setColorCount(256);
    for (int i = 0; i < 256; ++i) {
        img.setColor(i, qRgb(i, i, i));
    }

    double minH = m_dem.minHeight();
    double maxH = m_dem.maxHeight();
    double range = maxH - minH;
    if (range <= 0.0) range = 1.0;

    for (int r = 0; r < rows; ++r) {
        for (int c = 0; c < cols; ++c) {
            double h = m_dem.heightAt(r, c);
            int gray = (int)((h - minH) * 255.0 / range);
            if (gray < 0) gray = 0;
            if (gray > 255) gray = 255;
            img.setPixel(c, r, gray);
        }
    }

    QPixmap pix = QPixmap::fromImage(img.scaled(cols * 4, rows * 4));
    m_scene->addPixmap(pix);
    m_scene->setSceneRect(pix.rect());
}

void MainWindow::onComputeViewField()
{
    if (m_dem.rows() <= 0 || m_dem.cols() <= 0) {
        QMessageBox::warning(this, "No DEM", "Load a DEM file first.");
        return;
    }

    int cx = m_centerX->value();
    int cy = m_centerY->value();
    int radius = m_radius->value();
    double fov = m_fovDeg->value();
    double camH = m_cameraHeight->value();

    m_output->clear();
    m_output->append(QString("Center: (%1, %2), radius = %3 cells").arg(cx).arg(cy).arg(radius));
    m_output->append(QString("FOV(deg) = %1, Camera height = %2").arg(fov).arg(camH));
    m_output->append("");

    double r2 = radius * radius;
    double minH = 1e9;
    double maxH = -1e9;
    double sumH = 0.0;
    int count = 0;

    int rows = m_dem.rows();
    int cols = m_dem.cols();

    for (int r = cy - radius; r <= cy + radius; ++r) {
        for (int c = cx - radius; c <= cx + radius; ++c) {
            if (!m_dem.isValidIndex(r, c))
                continue;

            int dy = r - cy;
            int dx = c - cx;
            double dist2 = dx * dx + dy * dy;
            if (dist2 <= r2) {
                double h = m_dem.heightAt(r, c);
                sumH += h;
                if (h < minH) minH = h;
                if (h > maxH) maxH = h;
                ++count;
            }
        }
    }

    if (count == 0) {
        m_output->append("No cells found inside radius.");
    } else {
        double avgH = sumH / (double)count;
        m_output->append(QString("Cells in view field: %1").arg(count));
        m_output->append(QString("Min height: %1").arg(minH));
        m_output->append(QString("Max height: %1").arg(maxH));
        m_output->append(QString("Avg height: %1").arg(avgH));

        double distance = radius;
        double footprint = 2.0 * distance * qTan((fov * M_PI / 180.0) / 2.0);
        m_output->append(QString("Approx. footprint diameter (in cell units) at distance %1 = %2")
                         .arg(distance).arg(footprint));
    }

    drawViewFieldOverlay(cx, cy, radius);
}

void MainWindow::drawViewFieldOverlay(int cx, int cy, int radius)
{
    if (!m_scene)
        return;

    const double scale = 4.0;
    double x = cx * scale;
    double y = cy * scale;
    double rad = radius * scale;

    QPen pen(Qt::red);
    pen.setWidth(2);
    QColor fillColor(255, 0, 0, 50);

    m_scene->addEllipse(x - rad, y - rad, 2 * rad, 2 * rad, pen, QBrush(fillColor));
}
