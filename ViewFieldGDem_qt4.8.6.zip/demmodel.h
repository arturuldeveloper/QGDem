#ifndef DEMMODEL_H
#define DEMMODEL_H

#include <QObject>
#include <QVector>

class DemModel : public QObject
{
    Q_OBJECT
public:
    explicit DemModel(QObject *parent = 0);

    bool loadFromFile(const QString &filePath, QString *errorMsg = 0);

    int rows() const { return m_rows; }
    int cols() const { return m_cols; }

    bool isValidIndex(int r, int c) const;
    double heightAt(int r, int c) const;

    double minHeight() const { return m_minHeight; }
    double maxHeight() const { return m_maxHeight; }

private:
    int m_rows;
    int m_cols;
    QVector<double> m_data;
    double m_minHeight;
    double m_maxHeight;
};

#endif // DEMMODEL_H
