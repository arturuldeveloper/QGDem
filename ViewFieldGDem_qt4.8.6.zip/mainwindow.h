#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class QGraphicsView;
class QGraphicsScene;
class QLineEdit;
class QPushButton;
class QSpinBox;
class QDoubleSpinBox;
class QTextEdit;

#include "demmodel.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void onLoadDem();
    void onComputeViewField();

private:
    void rebuildScene();
    void drawViewFieldOverlay(int cx, int cy, int radius);

    DemModel       m_dem;
    QGraphicsView *m_view;
    QGraphicsScene *m_scene;

    QLineEdit     *m_fileEdit;
    QPushButton   *m_loadButton;

    QSpinBox      *m_centerX;
    QSpinBox      *m_centerY;
    QSpinBox      *m_radius;
    QDoubleSpinBox *m_fovDeg;
    QDoubleSpinBox *m_cameraHeight;

    QTextEdit     *m_output;
};

#endif // MAINWINDOW_H
