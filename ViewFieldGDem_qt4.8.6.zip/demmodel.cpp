#include "demmodel.h"
#include <QFile>
#include <QTextStream>

DemModel::DemModel(QObject *parent)
    : QObject(parent),
      m_rows(0),
      m_cols(0),
      m_minHeight(0.0),
      m_maxHeight(0.0)
{
}

bool DemModel::loadFromFile(const QString &filePath, QString *errorMsg)
{
    QFile f(filePath);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        if (errorMsg) *errorMsg = "Cannot open file: " + filePath;
        return false;
    }

    QTextStream in(&f);
    int rows, cols;
    in >> rows >> cols;
    if (in.status() != QTextStream::Ok || rows <= 0 || cols <= 0) {
        if (errorMsg) *errorMsg = "Invalid header (rows cols).";
        return false;
    }

    QVector<double> data;
    data.reserve(rows * cols);

    double value;
    for (int r = 0; r < rows; ++r) {
        for (int c = 0; c < cols; ++c) {
            in >> value;
            if (in.status() != QTextStream::Ok) {
                if (errorMsg) *errorMsg = "Not enough height values in file.";
                return false;
            }
            data.append(value);
        }
    }

    if (data.isEmpty()) {
        if (errorMsg) *errorMsg = "No data in DEM.";
        return false;
    }

    m_rows = rows;
    m_cols = cols;
    m_data = data;

    m_minHeight = m_maxHeight = m_data[0];
    for (int i = 1; i < m_data.size(); ++i) {
        double h = m_data[i];
        if (h < m_minHeight) m_minHeight = h;
        if (h > m_maxHeight) m_maxHeight = h;
    }

    return true;
}

bool DemModel::isValidIndex(int r, int c) const
{
    return (r >= 0 && r < m_rows && c >= 0 && c < m_cols);
}

double DemModel::heightAt(int r, int c) const
{
    if (!isValidIndex(r, c)) return 0.0;
    int idx = r * m_cols + c;
    return m_data[idx];
}
