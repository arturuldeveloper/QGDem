ViewField to Height at DEM - Qt 4.8.6
======================================

This example project demonstrates how to:

* Load a simple DEM (Digital Elevation Model) from an ASCII grid file.
* Display it as a grayscale image using Qt 4.8.6 (QGraphicsView / QGraphicsScene).
* Define a "view field" as a circular region over the DEM (center + radius).
* Compute basic height statistics (min / max / average) for all DEM cells in that region.
* Visualize the view field as a semi-transparent red circle overlay.

Files
-----

- ViewFieldGDem.pro    : Qt project file.
- main.cpp             : Application entry point.
- mainwindow.h/.cpp    : UI and main logic.
- demmodel.h/.cpp      : Simple DEM loader and data model.
- sample_dem.txt       : Example 20x20 grid DEM.

How to build
------------

1. Open the folder in Qt Creator (Qt 4.8.6).
2. Open `ViewFieldGDem.pro`.
3. Configure and build the project.
4. Run the application.

How to use
----------

1. Click **"Load DEM"** and select `sample_dem.txt` (or any DEM in the same ASCII format).
2. Use **Center X / Center Y / Radius** to define the view field in DEM cell coordinates.
3. Optionally set **FOV (deg)** and **Camera height** (these are displayed and can be used for further geometry).
4. Click **"Compute ViewField"**.
5. The right panel shows:
   - Number of cells in the view field.
   - Min, max, and average height.
   - A rough footprint diameter estimate using the FOV.
6. The DEM view shows a red translucent circle representing the view field.

DEM ASCII format
----------------

The ASCII file must be:

    rows cols
    h11 h12 h13 ... h1N
    h21 h22 h23 ... h2N
    ...
    hM1 hM2 hM3 ... hMN

Where `rows` and `cols` are positive integers, and each `h` is a numeric height value.

You can replace `sample_dem.txt` with real DEM data or adapt `DemModel::loadFromFile`
to use GDAL/ASTER GDEM or other formats.
